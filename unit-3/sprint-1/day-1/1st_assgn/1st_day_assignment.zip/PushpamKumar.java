public class PushpamKumar{
	public static void main(String[] args){
	System.out.println("Name:"+"Pushpam Kumar");
	System.out.println("Father's name:"+"Kameshwar Prasad");
	System.out.println("Mother's name:"+"Meera");
	System.out.println("Age:"+"24");
	System.out.println("Gender:"+"M");
	System.out.println("Address:"+"Patna");
	System.out.println("Mobile no."+"1234567890");

	} 

}